# Exercise One

A Pen created on CodePen.io. Original URL: [https://codepen.io/Serouse2/pen/eYrBZvQ](https://codepen.io/Serouse2/pen/eYrBZvQ).

